# Corrosion metal > 2024-12-14 3:13pm
https://universe.roboflow.com/corrosion-metal-y-corrosion/corrosion-metal

Provided by a Roboflow user
License: CC BY 4.0

